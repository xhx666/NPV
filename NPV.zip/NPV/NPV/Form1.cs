﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NPV
{
    public partial class Form1 : Form
    {
        ClassBean bean = new ClassBean();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_chengben.Text == "")
            {
                MessageBox.Show("总投资不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tb_chengben.Focus();
            }
            else if (tb_tiexian.Text == "")
            {
                MessageBox.Show("贴现率不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tb_tiexian.Focus();
            }
            else if (tb_year.Text == "")
            {
                MessageBox.Show("回收期不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tb_year.Focus();
            }
            else
            {

                if (tb_chengben.Text != null & tb_tiexian.Text != null && tb_year.Text != null)
                {
                    bean.setZcb(double.Parse(tb_chengben.Text));
                    bean.setJxl(double.Parse(tb_tiexian.Text));
                    bean.setYear(int.Parse(tb_year.Text));
                    dataGridView1.Rows.Clear();
                    for (int i = 0; i < bean.getYear() - 1; i++)
                    {
                        dataGridView1.Rows.Add();
                    }
                    for (int i = 0; i < bean.getYear(); i++)
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "第" + (i + 1) + "年";
                        dataGridView1.Rows[i].Cells[1].Value = "";
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
             double[] a ;
            a = new double[bean.getYear()];
            int n=0;
            for(int i=0;i<bean.getYear();i++)
            {
                if (dataGridView1.Rows[i].Cells[1].Value.ToString().Equals(""))
                    n++;
                else
                {
                   object b = dataGridView1.Rows[i].Cells[1].Value;
                   a[i] = double.Parse(b.ToString());
                }
            }
            if (n != 0)
            {
                MessageBox.Show("请输入完整的获利（元）！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                double vpn = 0;
                double q = bean.getJxl() / 100 + 1;
                for (int i = 0; i < bean.getYear(); i++)
                {
                    double p = Math.Pow(q, i + 1);
                    double g = 1 / p;
                    vpn += g* a[i];
                   
                }

                label8.Text = (vpn-bean.getZcb()).ToString("f2");
            }
        }

        private void tb_chengben_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 0x20) e.KeyChar = (char)0;  //禁止空格键
            if ((e.KeyChar == 0x2D) && (((TextBox)sender).Text.Length == 0)) return;   //处理负数
            if (e.KeyChar > 0x20)
            {
                try
                {
                    double.Parse(((TextBox)sender).Text + e.KeyChar.ToString());
                }
                catch
                {
                    e.KeyChar = (char)0;   //处理非法字符
                }
            }
        }

        private void tb_tiexian_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 0x20) e.KeyChar = (char)0;  //禁止空格键
            if ((e.KeyChar == 0x2D) && (((TextBox)sender).Text.Length == 0)) return;   //处理负数
            if (e.KeyChar > 0x20)
            {
                try
                {
                    double.Parse(((TextBox)sender).Text + e.KeyChar.ToString());
                }
                catch
                {
                    e.KeyChar = (char)0;   //处理非法字符
                }
            }
        }

        private void tb_year_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 0x20) e.KeyChar = (char)0;  //禁止空格键
            if ((e.KeyChar == 0x2D) && (((TextBox)sender).Text.Length == 0)) return;   //处理负数
            if (e.KeyChar > 0x20)
            {
                try
                {
                    double.Parse(((TextBox)sender).Text + e.KeyChar.ToString());
                }
                catch
                {
                    e.KeyChar = (char)0;   //处理非法字符
                }
            }
        }

        
        

        
    }
}

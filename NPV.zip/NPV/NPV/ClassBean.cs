﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPV
{
    class ClassBean
    {
        private double zcb;//总成本
        private int year;//回收期
        private double jxl;//净现率
        private double[] hl;

        public void setZcb(double zcb)
        {
            this.zcb = zcb;
        }
        public double getZcb()
        {
            return zcb;
        }

        public void setJxl(double jxl)
        {
            this.jxl = jxl;
        }
        public double getJxl()
        {
            return jxl;
        }

        public void setYear(int year)
        {
            this.year = year;
        }
        public int getYear()
        {
            return year;
        }

        public void setHl(double[] hl)
        {
            this.hl = hl;
        }
        public double[] getHl()
        {
            return hl;
        }
    }
}
